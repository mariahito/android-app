package com.example.student.activity0;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.View;

public class Activity0 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity0);
    }

    public void mainScreen(View view){
        if(view.getId()== R.id.convert){
            Intent i = new Intent(Activity0.this,Activity1.class);
            startActivity(i);
        }
        if(view.getId()== R.id.calc){
            Intent i = new Intent(Activity0.this,Activity2.class);
            startActivity(i);
        }
    }
}
