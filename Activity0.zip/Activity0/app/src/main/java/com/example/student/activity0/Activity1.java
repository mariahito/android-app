package com.example.student.activity0;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Activity1 extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity1);
    }

    public void convertTemp(View theCaller) {
        EditText inputTxt = (EditText)findViewById(R.id.inputTemp);
        TextView outputTemp= (TextView)findViewById(R.id.convertedTemp);

        float fTemp = Float.parseFloat(inputTxt.getText().toString());
        float outTemp = (fTemp - 32)*5/9;

        outputTemp.setText(""+outTemp);
    }


}
